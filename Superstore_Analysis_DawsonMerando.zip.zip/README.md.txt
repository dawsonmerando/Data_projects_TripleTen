# Superstore Analysis Project

## Tableau Public Dashboard
https://public.tableau.com/app/profile/dawson.merando/viz/Sprint4TableauProject_17592799068540/1_1-ProfitSub-Category?publish=yes

## Project Description

 - The East and West regions stand out more while the North and South regions are behind.
 - Washington in March, Indiana in October, and Vermont in November are the best combinations to advertise in.
 - Profits from the sales are totaling in the negatives.
 - There are several customers that have high return rates.
 - There are several products that have high return rates.
 - The top 2 segment combinations are Copiers in the West and Chairs in the East.
 - The bottom 2 segment combinations are Binders in the Central region and Tables in the East.